var files_dup =
[
    [ "ArduinoSnakePattern.cpp", "_arduino_snake_pattern_8cpp.html", "_arduino_snake_pattern_8cpp" ],
    [ "Collection.py", "_collection_8py.html", [
      [ "Collectador", "class_collection_1_1_collectador.html", "class_collection_1_1_collectador" ]
    ] ],
    [ "fakeSerial.py", "fake_serial_8py.html", [
      [ "Serial", "classfake_serial_1_1_serial.html", "classfake_serial_1_1_serial" ]
    ] ],
    [ "gui.py", "gui_8py.html", "gui_8py" ],
    [ "locationPopulate.cpp", "location_populate_8cpp.html", "location_populate_8cpp" ],
    [ "Mswitch.py", "_mswitch_8py.html", [
      [ "MSwitch", "class_mswitch_1_1_m_switch.html", "class_mswitch_1_1_m_switch" ]
    ] ],
    [ "Pump.py", "_pump_8py.html", "_pump_8py" ],
    [ "TwoSwitch.py", "_two_switch_8py.html", [
      [ "TwoSwitch", "class_two_switch_1_1_two_switch.html", "class_two_switch_1_1_two_switch" ]
    ] ],
    [ "XYStage_LimitSwitch_TwoSwitch_Control.cpp", "_x_y_stage___limit_switch___two_switch___control_8cpp.html", "_x_y_stage___limit_switch___two_switch___control_8cpp" ]
];