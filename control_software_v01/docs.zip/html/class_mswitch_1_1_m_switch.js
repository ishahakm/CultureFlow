var class_mswitch_1_1_m_switch =
[
    [ "__init__", "class_mswitch_1_1_m_switch.html#a0fb0dfae18d749480c2f1951f8d33e7d", null ],
    [ "chop_return", "class_mswitch_1_1_m_switch.html#a7f9619b4aa0ad0e06121c6c52b13dca4", null ],
    [ "get_info", "class_mswitch_1_1_m_switch.html#a340f3cb2d10d8fc3681c6f215201d331", null ],
    [ "send", "class_mswitch_1_1_m_switch.html#a5ed9dff363e8dcc66e12d6d9583ed491", null ],
    [ "serial_connect", "class_mswitch_1_1_m_switch.html#a1ea0e8470eaf51e2971ebbc55632b394", null ],
    [ "set_reservoir", "class_mswitch_1_1_m_switch.html#abc4ef313e6319d0d71197ffbed7be4c0", null ],
    [ "baud", "class_mswitch_1_1_m_switch.html#a3b1ad086eaa3a9a2bae7ad859b002e89", null ],
    [ "connected", "class_mswitch_1_1_m_switch.html#ae6a23408cddf05b083bd28601aa49abf", null ],
    [ "port", "class_mswitch_1_1_m_switch.html#abd91d2bc2bc947ce10e54949b84abe0e", null ],
    [ "res", "class_mswitch_1_1_m_switch.html#a2e2a57856e19dcaf023a0e83a1fda604", null ],
    [ "ser", "class_mswitch_1_1_m_switch.html#a936eb8588d8a9b8d5f5219867b5ca952", null ],
    [ "serialConnected", "class_mswitch_1_1_m_switch.html#a1dedffaf31ad772486347a9ceca3ccf2", null ],
    [ "uniqueID", "class_mswitch_1_1_m_switch.html#ada61613dc2da7e94b2f0464a7479603e", null ]
];