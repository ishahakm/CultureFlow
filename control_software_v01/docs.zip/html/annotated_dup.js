var annotated_dup =
[
    [ "Collection", "namespace_collection.html", "namespace_collection" ],
    [ "fakeSerial", "namespacefake_serial.html", "namespacefake_serial" ],
    [ "gui", "namespacegui.html", "namespacegui" ],
    [ "Mswitch", "namespace_mswitch.html", "namespace_mswitch" ],
    [ "Pump", "namespace_pump.html", "namespace_pump" ],
    [ "TwoSwitch", "namespace_two_switch.html", "namespace_two_switch" ]
];