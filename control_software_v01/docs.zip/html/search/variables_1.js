var searchData=
[
  ['baud',['baud',['../class_collection_1_1_collectador.html#a06c835183d4c66cf6c91c2e34ee3e2b6',1,'Collection.Collectador.baud()'],['../class_mswitch_1_1_m_switch.html#a3b1ad086eaa3a9a2bae7ad859b002e89',1,'Mswitch.MSwitch.baud()'],['../class_pump_1_1_three_pump.html#abc5f0f88b998c6ffbcac39f509f8276d',1,'Pump.ThreePump.baud()'],['../class_two_switch_1_1_two_switch.html#a9fe7ee9555de6382e4be1419d7580203',1,'TwoSwitch.TwoSwitch.baud()']]],
  ['baudrate',['baudrate',['../classfake_serial_1_1_serial.html#afe5ee18e12722951265fdd9d4fa81a51',1,'fakeSerial::Serial']]],
  ['buttonfont',['buttonFont',['../classgui_1_1_app.html#a6c43464b149411d3a1bd14477283d5f0',1,'gui::App']]],
  ['bytesize',['bytesize',['../classfake_serial_1_1_serial.html#afc2c7273bcb952833c250bda88ba2d08',1,'fakeSerial::Serial']]]
];
