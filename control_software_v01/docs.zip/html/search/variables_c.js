var searchData=
[
  ['pagefont',['pageFont',['../classgui_1_1_app.html#a2f7deeba59223d06f410a49d002b2e54',1,'gui::App']]],
  ['parity',['parity',['../classfake_serial_1_1_serial.html#a0b5e1c24e2dd47ba832bd4a26b5c0027',1,'fakeSerial::Serial']]],
  ['patternlabel',['patternLabel',['../classgui_1_1_manual_page.html#ad11be888b660401d0d693c9b89e57afb',1,'gui::ManualPage']]],
  ['perfusorframe',['perfusorframe',['../classgui_1_1_welcome_page.html#acf22ea45b4f78ec45bcf83f9c3d32c01',1,'gui::WelcomePage']]],
  ['port',['port',['../class_collection_1_1_collectador.html#a550345b45c253014500953908ed1a995',1,'Collection.Collectador.port()'],['../classfake_serial_1_1_serial.html#a53d2e25f2f6b6654ba6740cb57242758',1,'fakeSerial.Serial.port()'],['../class_mswitch_1_1_m_switch.html#abd91d2bc2bc947ce10e54949b84abe0e',1,'Mswitch.MSwitch.port()'],['../class_pump_1_1_three_pump.html#a0ac7dc541ee013051f95f0f0e1f135bb',1,'Pump.ThreePump.port()'],['../class_two_switch_1_1_two_switch.html#a125dcd40f5242394787f7f5b1f3cfe71',1,'TwoSwitch.TwoSwitch.port()']]],
  ['port2switch',['port2Switch',['../classgui_1_1_app.html#a82da4048722544098fb7de8e9a66678e',1,'gui::App']]],
  ['portcoll',['portColl',['../classgui_1_1_app.html#a3bf85840efd78e0e8ede4b11edecc0d6',1,'gui::App']]],
  ['portmani',['portMani',['../classgui_1_1_app.html#a0a0ff9ae77f8ab543ea53a1472726e0c',1,'gui::App']]],
  ['portpump',['portPump',['../classgui_1_1_app.html#a71142d3f164ba060bc8fd79085b41748',1,'gui::App']]],
  ['ports',['ports',['../classgui_1_1_app.html#a03e97a8c57a5c6dc3636589851677877',1,'gui::App']]],
  ['position',['position',['../class_collection_1_1_collectador.html#aa037ff041a29101bf42cde6fdb21061c',1,'Collection::Collectador']]],
  ['positionlabel',['positionLabel',['../classgui_1_1_manual_page.html#ac2d54d8c9e5e1138aad2907338d5521f',1,'gui::ManualPage']]],
  ['positions',['positions',['../_arduino_snake_pattern_8cpp.html#a843a18dd28fa7a7f9288bd6f7d6c6621',1,'positions():&#160;ArduinoSnakePattern.cpp'],['../_x_y_stage___limit_switch___two_switch___control_8cpp.html#a843a18dd28fa7a7f9288bd6f7d6c6621',1,'positions():&#160;XYStage_LimitSwitch_TwoSwitch_Control.cpp']]],
  ['pumplabel',['pumplabel',['../classgui_1_1_welcome_page.html#a750ef6fb7d0bd37635b2dd711b187067',1,'gui::WelcomePage']]]
];
