var searchData=
[
  ['manualpage',['ManualPage',['../classgui_1_1_manual_page.html',1,'gui']]],
  ['mswitch',['MSwitch',['../class_mswitch_1_1_m_switch.html',1,'Mswitch']]]
];
