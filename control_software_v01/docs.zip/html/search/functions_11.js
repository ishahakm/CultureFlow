var searchData=
[
  ['update',['update',['../classgui_1_1_settings_page.html#ac2445b28977183112566153e4040ea09',1,'gui::SettingsPage']]]
];
