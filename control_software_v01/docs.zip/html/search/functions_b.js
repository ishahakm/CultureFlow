var searchData=
[
  ['negative_5frun_5fstatus',['negative_run_status',['../classgui_1_1_app.html#acf736cd539fe969738a7f74d8232d2fb',1,'gui::App']]],
  ['next',['next',['../classgui_1_1_manual_page.html#a28ccffcefb06e61579ed0f583719a5cb',1,'gui::ManualPage']]],
  ['next_5fsite',['next_site',['../class_collection_1_1_collectador.html#aa156ce605af4adfec1bfb7aa8447eb65',1,'Collection::Collectador']]]
];
