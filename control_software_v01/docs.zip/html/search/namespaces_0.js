var searchData=
[
  ['collection',['Collection',['../namespace_collection.html',1,'']]]
];
