var searchData=
[
  ['isopen',['isOpen',['../classfake_serial_1_1_serial.html#a69cc2297e7c5bfb87de4df789774f3a2',1,'fakeSerial::Serial']]]
];
