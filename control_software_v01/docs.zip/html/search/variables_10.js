var searchData=
[
  ['uniqueid',['uniqueID',['../class_collection_1_1_collectador.html#a13c3d036cddedace173688b51df275d5',1,'Collection.Collectador.uniqueID()'],['../class_mswitch_1_1_m_switch.html#ada61613dc2da7e94b2f0464a7479603e',1,'Mswitch.MSwitch.uniqueID()'],['../class_two_switch_1_1_two_switch.html#a5facaddf7386248c105cedd41fb4812d',1,'TwoSwitch.TwoSwitch.uniqueID()']]],
  ['updatebutton',['updatebutton',['../classgui_1_1_settings_page.html#a8b32a4df0cd42d070635c54eab948859',1,'gui::SettingsPage']]],
  ['usingsnakepattern',['usingSnakePattern',['../class_collection_1_1_collectador.html#a7f70d1594de2d80376651c27572a6c1a',1,'Collection::Collectador']]]
];
