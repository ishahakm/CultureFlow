var searchData=
[
  ['write',['write',['../classfake_serial_1_1_serial.html#abc4ef915d782f9e4a8d1d6f398298a6d',1,'fakeSerial::Serial']]]
];
