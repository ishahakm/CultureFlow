var searchData=
[
  ['collectador',['Collectador',['../class_collection_1_1_collectador.html',1,'Collection']]]
];
