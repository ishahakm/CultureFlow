var searchData=
[
  ['name',['name',['../classfake_serial_1_1_serial.html#af3d8449c9f1992bbe479981375083651',1,'fakeSerial::Serial']]],
  ['newstep',['newstep',['../classgui_1_1_automatic_page.html#a356e4aa433a2fc1d033a3463632dc9fb',1,'gui::AutomaticPage']]],
  ['nextwellbutton',['nextwellbutton',['../classgui_1_1_manual_page.html#a7e31eb0aa8abe07fd58ffa23dd66f09e',1,'gui::ManualPage']]],
  ['number_5fdeleted',['number_deleted',['../classgui_1_1_automatic_page.html#a8445b7f6e0359f78a926e8a904bd2d59',1,'gui::AutomaticPage']]],
  ['numberlist',['numberlist',['../classgui_1_1_automatic_page.html#a208bec8e2ffcdf37665b930c1c00d888',1,'gui::AutomaticPage']]],
  ['numlocations',['numLocations',['../_arduino_snake_pattern_8cpp.html#a8e7d7b387f29f94a9fdd51ffe47974ad',1,'numLocations():&#160;ArduinoSnakePattern.cpp'],['../location_populate_8cpp.html#a8e7d7b387f29f94a9fdd51ffe47974ad',1,'numLocations():&#160;locationPopulate.cpp'],['../_x_y_stage___limit_switch___two_switch___control_8cpp.html#a8e7d7b387f29f94a9fdd51ffe47974ad',1,'numLocations():&#160;XYStage_LimitSwitch_TwoSwitch_Control.cpp']]]
];
