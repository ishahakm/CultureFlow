var searchData=
[
  ['app',['App',['../classgui_1_1_app.html',1,'gui']]],
  ['automaticpage',['AutomaticPage',['../classgui_1_1_automatic_page.html',1,'gui']]]
];
