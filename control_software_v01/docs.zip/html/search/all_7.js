var searchData=
[
  ['get_5fcomport',['get_comport',['../classgui_1_1_app.html#ab2635deb65f781dfe23d2fde7c3c93c8',1,'gui::App']]],
  ['get_5finfo',['get_info',['../class_collection_1_1_collectador.html#a23757363741c6dd611d91dd984013d86',1,'Collection.Collectador.get_info()'],['../class_mswitch_1_1_m_switch.html#a340f3cb2d10d8fc3681c6f215201d331',1,'Mswitch.MSwitch.get_info()']]],
  ['get_5fports',['get_ports',['../classgui_1_1_app.html#a1b5ba9c55ba86ed27afc50032e5fb41f',1,'gui.App.get_ports()'],['../namespace_pump.html#aff7d4116a67559ba3db8143f12fb4da6',1,'Pump.get_ports()']]],
  ['getidentifier',['getIdentifier',['../class_two_switch_1_1_two_switch.html#ac5eb2e77087de5dc473a0722b16863a5',1,'TwoSwitch::TwoSwitch']]],
  ['greaterlabelframe',['greaterlabelframe',['../classgui_1_1_manual_page.html#af3051ffdca2cc8da15359ca39934cc8d',1,'gui::ManualPage']]],
  ['gui',['gui',['../namespacegui.html',1,'']]],
  ['gui_2epy',['gui.py',['../gui_8py.html',1,'']]]
];
