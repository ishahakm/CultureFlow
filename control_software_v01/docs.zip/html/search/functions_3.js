var searchData=
[
  ['calibrate',['calibrate',['../classgui_1_1_settings_page.html#acf80cd46922483e88c69a77df3a0d4c2',1,'gui.SettingsPage.calibrate()'],['../class_pump_1_1_three_pump.html#ab85be09529a117c9f2c8160814c31881',1,'Pump.ThreePump.calibrate()']]],
  ['check_5fall_5fmanual',['check_all_manual',['../classgui_1_1_manual_page.html#ae70283a008dbdf796e148b4a3ce9c0fc',1,'gui::ManualPage']]],
  ['check_5fall_5fmanual_5fand_5fsampling',['check_all_manual_and_sampling',['../classgui_1_1_manual_page.html#a0aecdea93ced54d8ead080770b2526df',1,'gui::ManualPage']]],
  ['check_5fchannel',['check_channel',['../classgui_1_1_manual_page.html#a2b9736f35eed9710bbb1a40be20bc21a',1,'gui.ManualPage.check_channel()'],['../classgui_1_1_automatic_page.html#a17f4d7d7431114b208912620caa78af6',1,'gui.AutomaticPage.check_channel()']]],
  ['check_5finput',['check_input',['../namespacegui.html#a112dfa5ddd7d9664cf21062f7e725ce8',1,'gui']]],
  ['chop_5freturn',['chop_return',['../class_collection_1_1_collectador.html#a1fcc60319735e3e18d938c84073aef20',1,'Collection.Collectador.chop_return()'],['../class_mswitch_1_1_m_switch.html#a7f9619b4aa0ad0e06121c6c52b13dca4',1,'Mswitch.MSwitch.chop_return()'],['../class_pump_1_1_three_pump.html#adf760719a9c718d5aec4a70a8c8cab9e',1,'Pump.ThreePump.chop_return()'],['../class_two_switch_1_1_two_switch.html#a99d8b3d50bedbf126e1fbe10506e501f',1,'TwoSwitch.TwoSwitch.chop_return()']]],
  ['clear_5frecipe',['clear_recipe',['../classgui_1_1_automatic_page.html#ab4866c171e0c3f6c4d2911f0fe5c6b03',1,'gui::AutomaticPage']]],
  ['close',['close',['../classfake_serial_1_1_serial.html#a183f0034571d103c4c90c041e6643557',1,'fakeSerial::Serial']]],
  ['combine_5ffuncs',['combine_funcs',['../namespacegui.html#a8b03c359da973f07d331b9f8bacf8a06',1,'gui']]],
  ['create_5fchannels',['create_channels',['../classgui_1_1_manual_page.html#acc5098f07ab29863867f98a11d314451',1,'gui::ManualPage']]],
  ['create_5fstep',['create_step',['../classgui_1_1_automatic_page.html#ac1f38c3fd742bcbf0a936639283330f0',1,'gui::AutomaticPage']]]
];
