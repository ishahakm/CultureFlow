var searchData=
[
  ['serial',['Serial',['../classfake_serial_1_1_serial.html',1,'fakeSerial']]],
  ['settingspage',['SettingsPage',['../classgui_1_1_settings_page.html',1,'gui']]]
];
