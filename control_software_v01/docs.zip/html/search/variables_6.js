var searchData=
[
  ['greaterlabelframe',['greaterlabelframe',['../classgui_1_1_manual_page.html#af3051ffdca2cc8da15359ca39934cc8d',1,'gui::ManualPage']]]
];
