var searchData=
[
  ['fakeserial',['fakeSerial',['../namespacefake_serial.html',1,'']]]
];
