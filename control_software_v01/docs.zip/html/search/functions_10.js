var searchData=
[
  ['toggle',['toggle',['../classgui_1_1_manual_page.html#a033656cfd366b9be59abbbfa977460b6',1,'gui::ManualPage']]],
  ['toggle_5fpattern',['toggle_pattern',['../class_collection_1_1_collectador.html#afe1f8b5d2328cf6ea624682ea716401a',1,'Collection::Collectador']]]
];
