var searchData=
[
  ['mswitch',['Mswitch',['../namespace_mswitch.html',1,'']]]
];
