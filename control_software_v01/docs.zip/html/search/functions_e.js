var searchData=
[
  ['read',['read',['../classfake_serial_1_1_serial.html#a46f1021e19572ff944e886e53a51a1d1',1,'fakeSerial::Serial']]],
  ['readline',['readline',['../classfake_serial_1_1_serial.html#a58f35303f074c25e972c0b16c6382bf4',1,'fakeSerial::Serial']]],
  ['reset',['reset',['../class_collection_1_1_collectador.html#ada8c768e4da16031fe01afcef78957e1',1,'Collection.Collectador.reset()'],['../classgui_1_1_manual_page.html#afd759af883bbbc147da7af8193f680fb',1,'gui.ManualPage.reset()'],['../_arduino_snake_pattern_8cpp.html#ad20897c5c8bd47f5d4005989bead0e55',1,'reset():&#160;ArduinoSnakePattern.cpp'],['../_x_y_stage___limit_switch___two_switch___control_8cpp.html#ad20897c5c8bd47f5d4005989bead0e55',1,'reset():&#160;XYStage_LimitSwitch_TwoSwitch_Control.cpp']]],
  ['run_5frecipe',['run_recipe',['../classgui_1_1_automatic_page.html#ac239f947c6933ed3fdc11c5131c791c1',1,'gui::AutomaticPage']]]
];
