var searchData=
[
  ['open',['open',['../classfake_serial_1_1_serial.html#a2e4137a108e41f23e49735667d9b4c05',1,'fakeSerial::Serial']]]
];
