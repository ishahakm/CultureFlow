var namespace_collection =
[
    [ "Collectador", "class_collection_1_1_collectador.html", "class_collection_1_1_collectador" ]
];