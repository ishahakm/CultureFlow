var namespacefake_serial =
[
    [ "Serial", "classfake_serial_1_1_serial.html", "classfake_serial_1_1_serial" ]
];