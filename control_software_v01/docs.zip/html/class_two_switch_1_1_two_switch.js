var class_two_switch_1_1_two_switch =
[
    [ "__init__", "class_two_switch_1_1_two_switch.html#a762f6622ca527b12104b0593378f87fb", null ],
    [ "chop_return", "class_two_switch_1_1_two_switch.html#a99d8b3d50bedbf126e1fbe10506e501f", null ],
    [ "getIdentifier", "class_two_switch_1_1_two_switch.html#ac5eb2e77087de5dc473a0722b16863a5", null ],
    [ "send", "class_two_switch_1_1_two_switch.html#a00b015b6f700f4d524056ff1c9de7c72", null ],
    [ "serial_connect", "class_two_switch_1_1_two_switch.html#ad816a09389ad0fb8ea56471aa4e8819f", null ],
    [ "setCollect", "class_two_switch_1_1_two_switch.html#a755481c98e9abd57c5307217df83795b", null ],
    [ "setRecirculate", "class_two_switch_1_1_two_switch.html#a9c0f7d8f4a2af542cf574c11a9cee709", null ],
    [ "baud", "class_two_switch_1_1_two_switch.html#a9fe7ee9555de6382e4be1419d7580203", null ],
    [ "connected", "class_two_switch_1_1_two_switch.html#a643bdc6e214c03d08cba1b722be10e40", null ],
    [ "port", "class_two_switch_1_1_two_switch.html#a125dcd40f5242394787f7f5b1f3cfe71", null ],
    [ "ser", "class_two_switch_1_1_two_switch.html#a8b0bb4497dcb4bdba19597fa296e698b", null ],
    [ "serialConnected", "class_two_switch_1_1_two_switch.html#a06a3303adcbe39405325e87cd7d2bd8f", null ],
    [ "uniqueID", "class_two_switch_1_1_two_switch.html#a5facaddf7386248c105cedd41fb4812d", null ],
    [ "willRecirculate", "class_two_switch_1_1_two_switch.html#a31490d5047814007931a7b700d028a12", null ]
];