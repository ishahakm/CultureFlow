var namespaces_dup =
[
    [ "Collection", "namespace_collection.html", null ],
    [ "fakeSerial", "namespacefake_serial.html", null ],
    [ "gui", "namespacegui.html", null ],
    [ "Mswitch", "namespace_mswitch.html", null ],
    [ "Pump", "namespace_pump.html", null ],
    [ "TwoSwitch", "namespace_two_switch.html", null ]
];