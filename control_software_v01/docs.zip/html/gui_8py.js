var gui_8py =
[
    [ "App", "classgui_1_1_app.html", "classgui_1_1_app" ],
    [ "WelcomePage", "classgui_1_1_welcome_page.html", "classgui_1_1_welcome_page" ],
    [ "ManualPage", "classgui_1_1_manual_page.html", "classgui_1_1_manual_page" ],
    [ "AutomaticPage", "classgui_1_1_automatic_page.html", "classgui_1_1_automatic_page" ],
    [ "SettingsPage", "classgui_1_1_settings_page.html", "classgui_1_1_settings_page" ],
    [ "check_input", "gui_8py.html#a112dfa5ddd7d9664cf21062f7e725ce8", null ],
    [ "combine_funcs", "gui_8py.html#a8b03c359da973f07d331b9f8bacf8a06", null ],
    [ "message_prompt", "gui_8py.html#a287ef9f754edef8c39da895297753642", null ],
    [ "app", "gui_8py.html#af263120175dda5fb802cbe5ce9490b93", null ],
    [ "LARGE_FONT", "gui_8py.html#ac177936c9562254841e5e7f5fa210fb1", null ]
];