var hierarchy =
[
    [ "Collection.Collectador", "class_collection_1_1_collectador.html", null ],
    [ "Frame", null, [
      [ "gui.AutomaticPage", "classgui_1_1_automatic_page.html", null ],
      [ "gui.ManualPage", "classgui_1_1_manual_page.html", null ],
      [ "gui.SettingsPage", "classgui_1_1_settings_page.html", null ],
      [ "gui.WelcomePage", "classgui_1_1_welcome_page.html", null ]
    ] ],
    [ "Mswitch.MSwitch", "class_mswitch_1_1_m_switch.html", null ],
    [ "fakeSerial.Serial", "classfake_serial_1_1_serial.html", null ],
    [ "Pump.ThreePump", "class_pump_1_1_three_pump.html", null ],
    [ "Tk", null, [
      [ "gui.App", "classgui_1_1_app.html", null ]
    ] ],
    [ "TwoSwitch.TwoSwitch", "class_two_switch_1_1_two_switch.html", null ]
];