var class_g_u_i_1_1_welcome_page =
[
    [ "__init__", "class_g_u_i_1_1_welcome_page.html#aa88665446973a13fe29a978a1a9962e3", null ],
    [ "flip", "class_g_u_i_1_1_welcome_page.html#a7612699922f2f3789aa58e098797b949", null ],
    [ "coll_label", "class_g_u_i_1_1_welcome_page.html#a67a73c2b555ee6e4ab9eea5a3048e866", null ],
    [ "collectorframe", "class_g_u_i_1_1_welcome_page.html#acac39ff27c299df0066830308db34032", null ],
    [ "donebutton", "class_g_u_i_1_1_welcome_page.html#a6b31226c328fc95d90de406177cb7db8", null ],
    [ "mainlabel", "class_g_u_i_1_1_welcome_page.html#a9e6eeb6f60a722283ce51970482d60c8", null ],
    [ "manilabel", "class_g_u_i_1_1_welcome_page.html#abbb18b04d5919182a5ab2808cac1f5fa", null ],
    [ "perfusorframe", "class_g_u_i_1_1_welcome_page.html#a9228925baaa2dce27b3c403f6dc989fb", null ],
    [ "pumplabel", "class_g_u_i_1_1_welcome_page.html#a1760f2af3848183bb73cfec74b78f27c", null ],
    [ "sublabelframe", "class_g_u_i_1_1_welcome_page.html#a82599f77f38933702392daab0cf6a396", null ]
];