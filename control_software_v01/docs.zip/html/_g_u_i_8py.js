var _g_u_i_8py =
[
    [ "App", "class_g_u_i_1_1_app.html", "class_g_u_i_1_1_app" ],
    [ "WelcomePage", "class_g_u_i_1_1_welcome_page.html", "class_g_u_i_1_1_welcome_page" ],
    [ "ManualPage", "class_g_u_i_1_1_manual_page.html", "class_g_u_i_1_1_manual_page" ],
    [ "AutomaticPage", "class_g_u_i_1_1_automatic_page.html", "class_g_u_i_1_1_automatic_page" ],
    [ "SettingsPage", "class_g_u_i_1_1_settings_page.html", "class_g_u_i_1_1_settings_page" ],
    [ "check_input", "_g_u_i_8py.html#ab5eebe1279ba51c95948fa550f2bc96c", null ],
    [ "combine_funcs", "_g_u_i_8py.html#a4906784b90d5a5544ca9023bee63983e", null ],
    [ "message_prompt", "_g_u_i_8py.html#aae078fdef2bd79cc7c7c1f2a917c18b1", null ],
    [ "app", "_g_u_i_8py.html#aa8865a45ffd83d7c6062a02c169bc287", null ],
    [ "LARGE_FONT", "_g_u_i_8py.html#a0a43ec6a3ff3feb9855ba08afbe1cff4", null ]
];