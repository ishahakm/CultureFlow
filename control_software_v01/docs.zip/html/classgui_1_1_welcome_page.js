var classgui_1_1_welcome_page =
[
    [ "__init__", "classgui_1_1_welcome_page.html#ad76f3aa5300f247046acdc4a54caf51b", null ],
    [ "flip", "classgui_1_1_welcome_page.html#a3544802d544b577d46a633649ba3212b", null ],
    [ "coll_label", "classgui_1_1_welcome_page.html#a8a8f59dabb5188fbe1a0f6ea21933725", null ],
    [ "collectorframe", "classgui_1_1_welcome_page.html#a919dea50fcd83b99c88196268224a173", null ],
    [ "donebutton", "classgui_1_1_welcome_page.html#a2d18a0f85a5af10a25e877f312ecdb97", null ],
    [ "mainlabel", "classgui_1_1_welcome_page.html#a5586a2ff4e087c2d72539f90a6bade8b", null ],
    [ "manilabel", "classgui_1_1_welcome_page.html#ac473cc6367d751b57d827bee6b081fe1", null ],
    [ "perfusorframe", "classgui_1_1_welcome_page.html#acf22ea45b4f78ec45bcf83f9c3d32c01", null ],
    [ "pumplabel", "classgui_1_1_welcome_page.html#a750ef6fb7d0bd37635b2dd711b187067", null ],
    [ "sublabelframe", "classgui_1_1_welcome_page.html#a80e84cfdf7527c98d14573a143b6f0fd", null ]
];