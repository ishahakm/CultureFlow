var namespacegui =
[
    [ "App", "classgui_1_1_app.html", "classgui_1_1_app" ],
    [ "AutomaticPage", "classgui_1_1_automatic_page.html", "classgui_1_1_automatic_page" ],
    [ "ManualPage", "classgui_1_1_manual_page.html", "classgui_1_1_manual_page" ],
    [ "SettingsPage", "classgui_1_1_settings_page.html", "classgui_1_1_settings_page" ],
    [ "WelcomePage", "classgui_1_1_welcome_page.html", "classgui_1_1_welcome_page" ]
];