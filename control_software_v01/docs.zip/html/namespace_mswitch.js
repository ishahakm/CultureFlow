var namespace_mswitch =
[
    [ "MSwitch", "class_mswitch_1_1_m_switch.html", "class_mswitch_1_1_m_switch" ]
];