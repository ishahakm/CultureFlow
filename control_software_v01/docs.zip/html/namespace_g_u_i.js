var namespace_g_u_i =
[
    [ "App", "class_g_u_i_1_1_app.html", "class_g_u_i_1_1_app" ],
    [ "AutomaticPage", "class_g_u_i_1_1_automatic_page.html", "class_g_u_i_1_1_automatic_page" ],
    [ "ManualPage", "class_g_u_i_1_1_manual_page.html", "class_g_u_i_1_1_manual_page" ],
    [ "SettingsPage", "class_g_u_i_1_1_settings_page.html", "class_g_u_i_1_1_settings_page" ],
    [ "WelcomePage", "class_g_u_i_1_1_welcome_page.html", "class_g_u_i_1_1_welcome_page" ]
];